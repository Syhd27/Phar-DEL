package com.example.phar_del;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.widget.Button;
import android.widget.Toast;

public class Home_page extends AppCompatActivity {
    boolean isPressed = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);
        getSupportActionBar().hide();

    }

    @Override
    public void onBackPressed() {
        //Check condition
        if (isPressed){
            //When double back pressed within a second
            //Clear all activity
            finishAffinity();
            //Exit
            System.exit(0);
        }else {
            //WHen double back press delay for 2 seconds
            //Display Toast
            Toast.makeText(getApplicationContext()
                    ,"Please click again to exit."
                    ,Toast.LENGTH_SHORT).show();
            //Set true
            isPressed = true;
        }
        //initialize runnable
        Runnable runnable = new Runnable() {
            @Override
            public void run() {
                //set false
                isPressed = false;
            }
        };
        //Handler delay for 2 seconds
        new Handler().postDelayed(runnable,2000);
    }
}